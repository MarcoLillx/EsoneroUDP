/*
 ============================================================================
 Name        : Esercizio-Server-Udp.c
 Author      : Ferrulli Francesco
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <string.h> /* for memset() */
#include "NetMessage.h"
#include <math.h>
#define ECHOMAX 255
#define PORT 60000
#define NO_ERROR 0

void ErrorHandler(char *errorMessage) {
	printf(errorMessage);
}
void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

// mathematical operations
void calculate(data *msg); // determines which operation to execute
void add(data*);
void mult(data*);
void sub(data*);
void division(data*);

void initializeWSDATA(WSADATA *wsa_data) {
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != 0) {
		ErrorHandler("error with WSDATA initialization\n");
	}
}

int main(int argc, char *argv[]) {
#if defined WIN32
	WSADATA wsa_data;
	initializeWSDATA(&wsa_data);
#endif
	// set the port number if passed by argument
	int port;
	if (argc > 1) {
		port = atoi(argv[1]);	// convert port number in binary format
	} else
		port = PORT;

	if (port < 0) {
		printf("invalid number port: %s\n", argv[1]);
		return 0;
	}

	int sock;
	struct sockaddr_in ServAddr;
	struct sockaddr_in ClntAddr;
	unsigned int cliAddrLen;

	int recvMsgSize;

	// socket creation
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
		ErrorHandler("socket() failed");

	// construct server address
	memset(&ServAddr, 0, sizeof(ServAddr));
	ServAddr.sin_family = AF_INET;
	ServAddr.sin_port = htons(port);
	ServAddr.sin_addr.s_addr = inet_addr("127.0.0.1");


	// assign server address to socket
	if ((bind(sock, (struct sockaddr *)&ServAddr, sizeof(ServAddr))) < 0)
		ErrorHandler("bind() failed");

	printf("waiting for a client request...\n");
	// client-server comunication
	while(1) {
		data buf;
		struct hostent *host;
		struct in_addr ina;

		// receiving data from client
		cliAddrLen = sizeof(ClntAddr);
		recvMsgSize = recvfrom(sock, &buf, sizeof(data), 0, (struct sockaddr*)&ClntAddr, &cliAddrLen);

		// retreive client symbolic address
		const char *ip = inet_ntoa(ClntAddr.sin_addr);
		ina.s_addr = inet_addr (ip);
		host = gethostbyaddr((char *) &ina, 4, AF_INET);

		fflush(stdout);

		//printf("\nResult of gethostbyaddr(localhost): %s\n", inet_ntoa(ina));

		char* canonical_name = host->h_name;

		printf("\nOperation requested %c %d %d from client %s, ip %s\n" , buf.operator,buf.firstOperand,buf.secondOperand,canonical_name,inet_ntoa(ClntAddr.sin_addr));

		calculate(&buf); // calculate the operation

		// sending data to client
		if (sendto(sock, &buf, sizeof(data), 0, (struct sockaddr *)&ClntAddr, sizeof(ClntAddr)) != sizeof(data))
			ErrorHandler("sendto() sent different number of bytes than expected\n");



	}
	system("pause");
	return 0;
}

/* function that decides the operation*/
void calculate(data *msg) {

	if (msg->operator == '+')
		add(msg);
	else if (msg->operator == '-')
		sub(msg);
	else if (msg->operator == '*')
		mult(msg);
	else
		division(msg);
	if(msg->error==1)
		printf("\n%s\n",msg->errorMsg);
	else if (fmod(msg->result,1) != 0)
		printf("\nresult: %.2f", msg->result);
	else
		printf("\nresult: %.0f", msg->result);
}

/* function that sums the first operand to the second operand */
void add(data *msg) {
	msg->result = msg->firstOperand + msg->secondOperand;
}
/* function that multiplies the first operand to the second operand */
void mult(data *msg) {
	msg->result = msg->firstOperand * msg->secondOperand;
}
/* function that subtracts the second operand to the first operand */
void sub(data *msg) {
	msg->result = msg->firstOperand - msg->secondOperand;
}
/* function that divides the first operand by the second operand */
void division(data *msg) {
	if (msg->secondOperand == 0) {
		msg->result = 0;
		strcpy(msg->errorMsg, "Cannot divide by 0");
		msg->error = 1;
	} else
		msg->result = (float)msg->firstOperand / (float)msg->secondOperand;
}
