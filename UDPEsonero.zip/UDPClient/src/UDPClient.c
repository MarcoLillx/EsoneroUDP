/*
 ============================================================================
 Name        : Esercizio-Client-Udp.c
 Author      : Marco Angelo Lillo
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h> /* for memset() */
#include "NetMessage.h"
#include <math.h>
#include <conio.h>
#define ECHOMAX 255
#define PORT 60000
#define NO_ERROR 0

void printHelp() {

	printf("\nsyntax of the calculator:\n");
	printf("		[operator] [number] [number]\n");
	printf("		- operator must be one of these: + , - , * , / , = \n");
	printf("		- number : integer number\n");
	printf("			'=' is used to close the connection with the server");

}

void ErrorHandler(char *errorMessage) {
	printf(errorMessage);
}
void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}


int readData(data *msg);

void initializeWSDATA(WSADATA *wsa_data) {
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != 0) {
		ErrorHandler("error with WSDATA initialization\n");
	}
}

int main(int argc, char *argv[]) {
#if defined WIN32
	WSADATA wsa_data;
	initializeWSDATA(&wsa_data);
#endif

	// set the port number and server address if passed by arguments
	char serverName[25];
	char *serverAddress;
	const char s[2] = ":";
	int port;
	if (argc > 1) {
		// divide the string when character ':' is found
		serverAddress = strtok(argv[1],s);
		strcpy(serverName,serverAddress);

		serverAddress = strtok(NULL,s);
		port = atoi(serverAddress);

	} else {
		strcpy(serverName, "localhost");
		port = PORT;
	}


	int sock;
	struct sockaddr_in ServAddr;
	struct sockaddr_in fromAddr;
	unsigned int fromSize;
	int bytes_rcvd;

	// socket creation
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		ErrorHandler("socket() failed");
		return -1;
	}
	// server address construction
	memset(&ServAddr, 0, sizeof(ServAddr));
	ServAddr.sin_family = PF_INET;
	ServAddr.sin_port = htons(port);

	struct hostent *host;
	struct in_addr* ina;
	host = gethostbyname(serverName);
	if (host == NULL) {
		fprintf(stderr, "gethostbyname() failed.\n");
		exit(EXIT_FAILURE);
	} else {
		ina = (struct in_addr*) host->h_addr_list[0];
		printf("Result of gethostbyname(%s): %s\n", serverName, inet_ntoa(*ina));
	}

	ServAddr.sin_addr.s_addr = inet_addr(inet_ntoa(*ina));

	//fflush(stdout);
	// begin client-server comunication

	printHelp();
	while (1) {
		data msg;
		int choice = readData(&msg);
		if (choice == -1) {
			closesocket(sock);
			ClearWinSock();
			printf("\n\n");
			system("pause");
			return 0;
		} else {

			// sending data to server
			if (sendto(sock, &msg, sizeof(data), 0, (struct sockaddr*)&ServAddr, sizeof(ServAddr)) != sizeof(data)) {
				ErrorHandler("sendto() sent different number of bytes than expected\n");
			}

			// receiving data from server
			fromSize = sizeof(fromAddr);
			bytes_rcvd = recvfrom(sock, &msg, sizeof(data), 0, (struct sockaddr*)&fromAddr, &fromSize);

			if (ServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
			{
				fprintf(stderr, "Error: received a packet from unknown source.\n");
				exit(EXIT_FAILURE);
			}

			if (msg.error == 1)
				printf("\n\n%s", msg.errorMsg); // print error message relative to division by 0
			else {

				struct hostent *host;
				host = gethostbyaddr((char *) &fromAddr.sin_addr, 4, AF_INET);
				char* canonical_name = host->h_name;

				if(fmod(msg.result,1) != 0) // fmod return the remainder of the division
					printf("\n\nReceived result from server %s,ip %s: %d %c %d = %.2f \n",serverName,inet_ntoa(*ina),msg.firstOperand,msg.operator,msg.secondOperand, msg.result);
				else
					printf("\n\nReceived result from server %s,ip %s: %d %c %d = %.0f \n",serverName,inet_ntoa(*ina),msg.firstOperand,msg.operator,msg.secondOperand, msg.result);
			}

		}

	}

	closesocket(sock);
	ClearWinSock();
	system("pause");
	return EXIT_SUCCESS;
}
int readData(data *msg) {

	printf("\ninsert the operation to calculate: ");
	char ch;
	msg->error = 0;
	while (ch != 13) {
		ch = getch();
		while ((ch != '=') & (ch != '+') & (ch != '-') & (ch != '*')
				& (ch != '/'))
			ch = getch();

		if (ch == '=')
			return -1;
		if ((ch == '+') | (ch == '-') | (ch == '/') | (ch == '*')) {
			printf("%c", ch);
			msg->operator = ch;
		}

		// insert whitespace
		ch = getch();
		while (ch != 32)
			ch = getch();
		printf("%c", ch);

		char number[20] = "";
		int n = 0;

		// insert at least one number of first operand
		ch = getch();
		while ((ch < '0') | (ch > '9'))
			ch = getch();
		printf("%c", ch);

		n = ch - 48;
		strncat(number, &ch, 1);

		// insert the rest of numbers
		while (ch != 32) {
			ch = getch();

			if ((ch >= '0') & (ch <= '9')) {
				printf("%c", ch);
				strncat(number, &ch, 1);
				n = n * 10 + (ch - 48);
			}

			if (ch == 32) {
				printf("%c", ch);
				//msg->firstOperand = atoi(number);
				msg->firstOperand = n;
			}
		}

		n = 0;
		strcpy(number, "");

		// insert at least one number of second operand
		ch = getch();
		while ((ch < '0') | (ch > '9'))
			ch = getch();
		printf("%c", ch);
		n = ch - 48;

		strncat(number, &ch, 1);

		// insert the rest of numbers
		while (ch != 13) {
			ch = getch();

			if ((ch >= '0') & (ch <= '9')) {
				printf("%c", ch);
				n = n * 10 + (ch - 48);
				strncat(number, &ch, 1);
			}

			if (ch == 13) {
				printf("%c", ch);
				msg->secondOperand = n;
			}
		}

	}
	return 0;
}
